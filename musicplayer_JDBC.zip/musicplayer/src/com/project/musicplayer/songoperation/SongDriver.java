package com.project.musicplayer.songoperation;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;
import java.util.Scanner;

import com.project.musicplayer.song.Song;

public class SongDriver {

	private static Connection connection;
	private static PreparedStatement preparedStatement;
	private static FileReader fileReader;
	private static ResultSet resultSet;
	private static Properties properties;
	private static int result;
	private static String filePath = "D:\\JAVA\\WEJA1\\musicplayer\\src\\resources\\db_info.properties";
	private static Scanner sc;
	private static Song song;

	public static void openConnection() {
		try {
			sc = new Scanner(System.in);
			fileReader = new FileReader(filePath);
			properties = new Properties();
			properties.load(fileReader);

			connection = DriverManager.getConnection(properties.getProperty("dburl"), properties);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void closeConnection() {
		try {
			if (connection != null) {
				connection.close();
			}
			if (preparedStatement != null) {
				preparedStatement.close();
			}
			if (resultSet != null) {
				resultSet.close();
			}
			if (fileReader != null) {
				fileReader.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void addSong() {
		try {
			System.out.println("******************* ADD SONG ************************");
			openConnection();
			preparedStatement = connection.prepareStatement(properties.getProperty("insertQuery"));
			
			boolean loop = true;
			while (loop) {

				System.out.print("Enter Song Id : ");
				preparedStatement.setInt(1, sc.nextInt());
				
				System.out.print("Enter Song Name : ");
				preparedStatement.setString(2, sc.next());
				
				System.out.print("Enter Song Duration : ");
				preparedStatement.setDouble(3, sc.nextDouble());
				
				System.out.print("Enter Singer Name : ");
				preparedStatement.setString(4, sc.next());
				
				System.out.print("Enter Album Name : ");
				preparedStatement.setString(5, sc.next());

				result = preparedStatement.executeUpdate();
				System.out.println(result + " Song added ");
				
				System.out.println(" 1. Add Next Song \n 2. Go back ");
				int input = sc.nextInt();
				if (input == 2) {
					loop = false;
					System.out.println("Going Back \n ______________________________");
				}
				
				

			}
		} catch (Exception e) {
			System.out.println("Invalid input or duplicate id");
		} finally {
			closeConnection();
		}
	}

	public void getSong() {
		try {
			openConnection();
			preparedStatement = connection.prepareStatement(properties.getProperty("selectQuery"));

			resultSet = preparedStatement.executeQuery();
			if (resultSet.isBeforeFirst()) {
				System.out.println("********************* PLAY All *********************** \n Playing all Song");
				while (resultSet.next()) {
					System.out.println(resultSet.getString(1) + " | " + resultSet.getString(2) + " | "
							+ resultSet.getDouble(3) + " | " + resultSet.getString(4) + " | " + resultSet.getString(5));
					Thread.sleep(1000);
				}
				System.out.println(" 1. Go home ");
				int input = sc.nextInt();
				if (input == 1) {
					System.out.println("Going Home page");
				}
			} else {
				System.out.println("Opps !! No Song is avilable... Please add song first");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeConnection();
		}

	}

	public void chooseSong() {
		try {
			openConnection();
			System.out.println("____ Select Song ___");

			preparedStatement = connection.prepareStatement(properties.getProperty("selectQuery"));

			resultSet = preparedStatement.executeQuery();
			
			//JDBC Object implementation
			while (resultSet.next()) {
				song = new Song();
				song.setSongId(resultSet.getInt(1));
				song.setSongName(resultSet.getString(2));
				song.setSongDuration(resultSet.getDouble(3));
				song.setSingerName(resultSet.getString(4));
				song.setAlbumName(resultSet.getString(5));
				
				System.out.println(song);
			}


			System.out.println("Enter Song Name : ");
			
			preparedStatement = connection.prepareStatement(properties.getProperty("searchQuery"));
			preparedStatement.setString(1, sc.next());

			resultSet = preparedStatement.executeQuery();

			if (resultSet.isBeforeFirst()) {
				while (resultSet.next()) {
					System.out.println(resultSet.getString(1) + " | " + resultSet.getString(2) + " | "
							+ resultSet.getDouble(3) + " | " + resultSet.getString(4) + " | " + resultSet.getString(5));
				}
			} else {
				System.out.println("Song not present");
			}

		} catch (Exception e) {
			System.out.println("Invalid input");
		}finally {
			closeConnection();
		}
	}
	public void deleteAll() {
		try {
			openConnection();
			preparedStatement = connection.prepareStatement(properties.getProperty("truncateQuery"));
			preparedStatement.executeUpdate();
			
			System.out.println("All song deleted");
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			closeConnection();
		}
	}
}
