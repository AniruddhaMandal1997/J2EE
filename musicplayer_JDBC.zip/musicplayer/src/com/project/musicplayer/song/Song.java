package com.project.musicplayer.song;

public class Song {
	private int songId;
	private String songName;
	private double songDuration;
	private String singerName;
	private String albumName;
	
	public int getSongId() {
		return songId;
	}

	public void setSongId(int songId) {
		this.songId = songId;
	}

	public String getSongName() {
		return songName;
	}

	public void setSongName(String songName) {
		this.songName = songName;
	}

	public double getSongDuration() {
		return songDuration;
	}

	public void setSongDuration(double songDuration) {
		this.songDuration = songDuration;
	}

	public String getSingerName() {
		return singerName;
	}

	public void setSingerName(String singerName) {
		this.singerName = singerName;
	}

	public String getAlbumName() {
		return albumName;
	}

	public void setAlbumName(String albumName) {
		this.albumName = albumName;
	}

	@Override
	public String toString() {
		return "[ Id : " + songId+ " || Name : "+ songName + " || Duration : " +songDuration+ "s || Singer : "+singerName +" || Album : " +albumName;
	}
	
	
}
