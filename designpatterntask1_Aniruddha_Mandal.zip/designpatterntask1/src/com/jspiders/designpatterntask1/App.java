package com.jspiders.designpatterntask1;

public class App {

}
