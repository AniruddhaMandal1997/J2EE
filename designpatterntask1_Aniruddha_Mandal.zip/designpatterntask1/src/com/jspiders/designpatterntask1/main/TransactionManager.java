package com.jspiders.designpatterntask1.main;

import java.util.NoSuchElementException;
import java.util.Scanner;

import com.jspiders.designpatterntask1.object.CheckBalance;
import com.jspiders.designpatterntask1.object.Deposite;
import com.jspiders.designpatterntask1.object.Withdraw;
import com.jspiders.designpatterntask1.resource.Account;
import com.jspiders.designpatterntask1.transaction.Transaction;

public class TransactionManager {
	static Transaction transaction;

	public static void main(String[] args) {

		Account account = Account.getAccountObject();

		boolean loop = true;

		while (loop) {

			System.out.println("_____WELCOME_____");
			System.out.println("1. Diposite amount\n" + "2. Withdwaw amount\n" + "3. Check balance\n" + "4. Exit");
			Scanner sc = new Scanner(System.in);
			int choose = sc.nextInt();

			try {
				switch (choose) {
				case 1:
					transaction = new Deposite(account);
					break;
				case 2:
					transaction = new Withdraw(account);
					break;
				case 3:
					transaction = new CheckBalance(account);
					break;
				case 4:
					loop = false;
					sc.close();
					break;
				default:
					System.out.println("Invalid input");
					break;
				}

			} catch (NoSuchElementException e) {
				System.out.println("Invalid input");
			}
		}

	}

}
