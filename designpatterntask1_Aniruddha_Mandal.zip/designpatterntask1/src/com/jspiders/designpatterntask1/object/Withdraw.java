package com.jspiders.designpatterntask1.object;

import java.util.Scanner;
import com.jspiders.designpatterntask1.resource.Account;
import com.jspiders.designpatterntask1.transaction.Transaction;

public class Withdraw implements Transaction {
	
	int withdrawAmount;

	public Withdraw(Account account) {
		withdraw();
	}
	
	
	public void withdraw() {
		
		System.out.println("Enter amount to withdraw ");
		Scanner sc = new Scanner(System.in);
		int amount = sc.nextInt();
		
//		sc.close(); 
		if(Account.getAccountObject().getAccountBalance() < amount) {
			System.out.println("Insufficiant Fund");
		} else {
			int withdrawAmount = Account.getAccountObject().getAccountBalance() - amount;
			Account.getAccountObject().setWithdrawAmount(withdrawAmount);
			System.out.println(amount+ " amount Withdrawal successful....!!!!");
			System.out.println("Current Balance is : "+ Account.getAccountObject().getAccountBalance());
			System.out.println("-------------------------------");
		}
		
		
		
		
	}
}
