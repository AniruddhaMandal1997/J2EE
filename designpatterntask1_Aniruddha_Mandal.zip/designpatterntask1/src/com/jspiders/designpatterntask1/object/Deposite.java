package com.jspiders.designpatterntask1.object;

import java.util.Scanner;

import com.jspiders.designpatterntask1.resource.Account;
import com.jspiders.designpatterntask1.transaction.Transaction;

public class Deposite implements Transaction{
	
	int depositeAmount;

	public Deposite(Account account) {
		deposite();
	}
	
	
	public void deposite() {
		System.out.println("Enter amount to Deposite");
		Scanner sc = new Scanner(System.in);
		int amount = sc.nextInt();
		
		// sc.close();
		
		int depositeAmount = Account.getAccountObject().getAccountBalance() + amount;
		Account.getAccountObject().setDepositeAmount(depositeAmount);
		System.out.println(amount+ " amount Deposite successful.....!!!!!!!!!!");
		
		System.out.println("Current Balance is : "+ Account.getAccountObject().getAccountBalance());
		System.out.println("-------------------------------");
	}

}
