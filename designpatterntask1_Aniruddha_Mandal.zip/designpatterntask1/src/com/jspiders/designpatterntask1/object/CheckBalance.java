package com.jspiders.designpatterntask1.object;

import com.jspiders.designpatterntask1.resource.Account;
import com.jspiders.designpatterntask1.transaction.Transaction;

public class CheckBalance implements Transaction {
	
	
	 public CheckBalance(Account account) {
		 
		 System.out.println("Account balance is : " + checkBalance());
		 System.out.println("-------------------------------");
	}

	public int checkBalance() {
		return Account.getAccountObject().getAccountBalance();
		
	}
}
