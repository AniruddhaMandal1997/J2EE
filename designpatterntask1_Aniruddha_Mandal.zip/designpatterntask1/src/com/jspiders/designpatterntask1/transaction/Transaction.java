package com.jspiders.designpatterntask1.transaction;

public interface Transaction {
	
}
